package com.hcl.selenium.tests;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.hcl.selenium.base.BasePage;
import com.hcl.selenium.data.ReadExcelFile;
import com.hcl.selenium.pages.ShopHPBrandLap;
import com.hcl.selenium.pages.VerifyLogin;

public class ShopHPBrand extends BasePage {
	BasePage objBase;
	VerifyLogin objLogin;
	ShopHPBrandLap objShop;

	@BeforeMethod
	public void launch() {
		objBase = new BasePage();
		objBase.setUp();

	}

	@DataProvider(name = "LoginData")
	public String[][] getData() throws IOException {

		// get the data from excel
		String path = "C:\\Users\\polarapuvenka.sailo\\Hackathons_Workspace\\SeleniumHackathon\\src\\main\\java\\com\\hcl\\selenium\\data\\LoginData.xlsx";
		ReadExcelFile util = new ReadExcelFile(path);

		int totalrows = util.getRowCount("Sheet1");
		int totalcols = util.getCellCount("Sheet1", 1);

		String loginData[][] = new String[1][totalcols];

		for (int i = 1; i <= 1; i++) // 1
		{
			for (int j = 0; j < totalcols; j++) // 0
			{
				loginData[i - 1][j] = util.getCellData("sheet1", i, j);
			}

		}

		return loginData;
	}

	@Test(priority = 1, enabled = true, dataProvider = "LoginData")
	public void selectHPLap(String username, String password) {
		objLogin = new VerifyLogin(driver);
		// login.loginVerify(
		WebDriverWait wait = new WebDriverWait(driver, 70);
		wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Hello, Sign in')]")));
		objLogin.signIn.click();
		objLogin.email.sendKeys(username);
		objLogin.continuee.click();
		System.out.println("username entered successfully");
		objLogin.passwordd.sendKeys(password);
		objLogin.signInButton.click();
		System.out.println("password entered successfully");
		objShop = new ShopHPBrandLap();
		objShop.shopHPLaptop();

	}

	@AfterMethod

	public void tearDown() throws InterruptedException {
		Thread.sleep(3000);
		driver.quit();

	}
}
