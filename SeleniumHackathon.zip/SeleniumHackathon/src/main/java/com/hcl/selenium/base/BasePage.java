package com.hcl.selenium.base;

import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.hcl.selenium.data.ReadExcelFile;


public class BasePage {
	public static WebDriver driver;
	public static Properties props;

	public BasePage() {

		try {
			props = new Properties();
			FileInputStream fis = new FileInputStream(
					"C:\\Users\\polarapuvenka.sailo\\Hackathons_Workspace\\SeleniumHackathon\\src\\main\\java\\"
					+ "com\\hcl\\selenium\\config\\config.properties");
			props.load(fis);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
  
	public  void setUp() {

		System.setProperty("webdriver.chrome.driver", props.getProperty("driverPath"));
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		//driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(ReadExcelFile.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(ReadExcelFile.IMPLICIT_WAIT, TimeUnit.SECONDS);
		driver.manage().deleteAllCookies();
		driver.get(props.getProperty("url"));


	}

}



