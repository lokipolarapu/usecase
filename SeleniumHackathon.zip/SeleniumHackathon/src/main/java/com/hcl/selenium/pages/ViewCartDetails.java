package com.hcl.selenium.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;

import com.hcl.selenium.base.BasePage;

public class ViewCartDetails extends BasePage{

	@FindBy(xpath="//span[@id='nav-cart-count']")
	WebElement viewCart;

	public ViewCartDetails() {
		PageFactory.initElements(driver, this);
		
	}

 public void viewCartt() {
	  WebDriverWait wait = new WebDriverWait(driver,50);
      wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='nav-cart-count']")));
      
	 viewCart.click();
 }


}

