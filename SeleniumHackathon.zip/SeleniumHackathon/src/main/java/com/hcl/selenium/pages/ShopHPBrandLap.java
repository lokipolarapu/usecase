package com.hcl.selenium.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hcl.selenium.base.BasePage;

public class ShopHPBrandLap extends BasePage{
	
	
	@FindBy(xpath="//a[@id='nav-hamburger-menu']")
	WebElement menu;
	@FindBy(xpath="//a[@data-menu-id='8']")
    WebElement department;
	@FindBy(xpath="//a[contains(text(),'Laptops')]")
    WebElement laptop;
	@FindBy(xpath="//span[contains(text(),'HP') and @class='a-size-base a-color-base']")
    WebElement hp;
	@FindBy(xpath="(//span[contains(text(),'HP 15 (2021) Thin & Light Ryzen 5 3500U Laptop, 8GB RAM, 512GB SSD, 39.62 cms (15.6\") FHD Screen, Windows 10, MS Office, Natural Silver (15s-gr0500AU)')])[1]")
    WebElement laptophp;
	@FindBy(xpath="//span[contains(text(),'Apple') and @class='a-size-base a-color-base']")
    WebElement apple;
	 
		@FindBy(xpath="//span[contains(text(),'2020 Apple MacBook Air (13.3-inch/33.78 cm, Apple M1 chip with 8-core CPU and 7-core GPU, 8GB RAM, 256GB SSD) - Space Grey')]")
	    WebElement laptopApple;
	
	//span[contains(text(),'Apple') and @class='a-size-base a-color-base']
	//span[contains(text(),'HP') and @class='a-size-base a-color-base']
	
	
	public ShopHPBrandLap() {
		PageFactory.initElements(driver, this);
	}

	public void shopHPLaptop() {
		WebDriverWait wait=new WebDriverWait(driver,50);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='nav-hamburger-menu']")));
		menu.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@data-menu-id='8']")));
		department.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'Laptops')]")));
		laptop.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'HP') and @class='a-size-base a-color-base']")));
		hp.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[contains(text(),'HP 15 (2021) Thin & Light Ryzen 5 3500U Laptop, 8GB RAM, 512GB SSD, 39.62 cms (15.6\") FHD Screen, Windows 10, MS Office, Natural Silver (15s-gr0500AU)')])[1]")));
		laptophp.click();
	}
  public void shopAppleLap() {
	  WebDriverWait wait=new WebDriverWait(driver,50);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='nav-hamburger-menu']")));
		menu.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@data-menu-id='8']")));
		department.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'Laptops')]")));
		laptop.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Apple') and @class='a-size-base a-color-base']")));
		apple.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'2020 Apple MacBook Air (13.3-inch/33.78 cm, Apple M1 chip with 8-core CPU and 7-core GPU, 8GB RAM, 256GB SSD) - Space Grey')]")));
		laptopApple.click();
	  
  }
}
