package com.hcl.selenium.pages;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hcl.selenium.base.BasePage;

public class AddToCart extends BasePage {
	@FindBy(xpath="//input[@id='add-to-cart-button']")
	public WebElement addToCart;
	
	public AddToCart()
	{
		PageFactory.initElements(driver, this);
	}
 
  public void addToCaart() {
	  //WebDriverWait wait=new WebDriverWait(driver,50);
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='add-to-cart-button']")));
	  String parent = driver.getWindowHandle();
      Set<String> s = driver.getWindowHandles();
      // Now iterate using Iterator
      Iterator<String> I1 = s.iterator();
     while (I1.hasNext()) {
          String child_window = I1.next();



          if (!parent.equals(child_window)) {
              driver.switchTo().window(child_window);
              WebDriverWait wait = new WebDriverWait(driver,50);
              wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='add-to-cart-button']")));
              
              
              //System.out.println(driver.switchTo().window(child_window).getTitle());
              //driver.close();
          }
           }
		addToCart.click();
  }
}
