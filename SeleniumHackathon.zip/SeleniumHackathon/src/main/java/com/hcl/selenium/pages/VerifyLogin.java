package com.hcl.selenium.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.hcl.selenium.base.BasePage;

public class VerifyLogin extends BasePage{
	WebDriver driver;
	@FindBy(xpath = "//span[contains(text(),'Hello, Sign in')]")
	public WebElement  signIn;
	//@FindBy(xpath = "//span[@id='nav-link-accountList-nav-line-1']")
	//public WebElement account;
	//@FindBy(xpath="//span[@class='nav-action-inner' and contains(text(),'Sign in')]")
	//@FindBy(xpath = "//span[@class='nav-action-inner']")
	
	@FindBy(xpath="//input[@name='email']")
	public WebElement email;
	@FindBy(xpath="//input[@id='continue']")
	public WebElement continuee;
	@FindBy(xpath="//input[@id='ap_password']")
	public WebElement passwordd;
	@FindBy(xpath="//input[@id='signInSubmit']")
	public WebElement signInButton;
	
	
	public VerifyLogin(WebDriver driver) {
		this.driver=driver;
	PageFactory.initElements(driver, this);
	//driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
	}
	
}
